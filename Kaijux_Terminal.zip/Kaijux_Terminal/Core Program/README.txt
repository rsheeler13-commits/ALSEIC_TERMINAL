Default password is: alseickaijux
you can change in script